# Calculator-Webpage
Calculator Webpage is a Web development Project  built using HTML,CSS and JS. This HTML document is hosted on  DriveToWeb -https://drv.tw/. DrivetoWeb lets you host web sites using free cloud storage and Google Drive.   

# Click on this below link to calculate simple calculations👇🏼👇🏼👇🏼         
# https://xypzljgtp0beyqfw9zedma-on.drv.tw/WEB/cal.html
